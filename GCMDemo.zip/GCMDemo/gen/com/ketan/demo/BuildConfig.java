/** Automatically generated file. DO NOT MODIFY */
package com.ketan.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}